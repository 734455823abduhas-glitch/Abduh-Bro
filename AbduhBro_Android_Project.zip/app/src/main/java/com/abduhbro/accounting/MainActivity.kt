package com.abduhbro.accounting

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abduhbro.accounting.data.AppDatabase
import com.abduhbro.accounting.data.FinancialEntry
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { AbduhBroApp(db) }
    }
}

data class Module(val title: String, val count: Int, val balance: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbduhBroApp(db: AppDatabase) {
    val scope = rememberCoroutineScope()
    var dark by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf("الرئيسية") }
    var showEntry by remember { mutableStateOf(false) }
    var entryType by remember { mutableStateOf("سند قبض") }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var records by remember { mutableStateOf(0) }
    val bg = if (dark) Color(0xFF101827) else Color(0xFFF3F6FA)
    val surface = if (dark) Color(0xFF1D2939) else Color.White
    val text = if (dark) Color.White else Color(0xFF172B4D)
    val blue = Color(0xFF1456A0)

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF6EA8FE)) else lightColorScheme(primary = blue)) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(
                title = { Column {
                    Text("Abduh Bro", fontWeight = FontWeight.Bold, color = Color.White)
                    Text("نظام إدارة ومحاسبة مصنع براڤو برو", fontSize = 12.sp, color = Color.White.copy(.85f))
                } },
                actions = {
                    IconButton(onClick = { dark = !dark }) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "الوضع الليلي", tint = Color.White)
                    }
                    IconButton(onClick = { active = "البحث" }) {
                        Icon(Icons.Default.Search, "بحث", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = blue)
            )
        }) { padding ->
            CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
                Column(Modifier.fillMaxSize().padding(padding).background(bg).padding(12.dp)) {
                    if (active != "الرئيسية") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { active = "الرئيسية" }) { Text("الرئيسية") }
                            Text(" / $active", color = text)
                        }
                    }
                    Text(if (active == "الرئيسية") "لوحة التحكم" else active, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = text)
                    Spacer(Modifier.height(10.dp))
                    if (active == "الرئيسية") {
                        Text("العمليات السريعة", fontWeight = FontWeight.Bold, color = text)
                        val quick = listOf("سند قبض", "سند صرف", "قيد متعدد", "فاتورة مبيعات", "فاتورة مشتريات", "حوالة جديدة", "أمر إنتاج", "مراجعة الحركات", "كشف حساب")
                        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(210.dp), verticalArrangement = Arrangement.spacedBy(7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(quick) { label ->
                                Card(Modifier.fillMaxWidth().height(62.dp).clickable {
                                    entryType = label
                                    showEntry = label !in listOf("مراجعة الحركات", "كشف حساب")
                                    active = if (showEntry) active else label
                                }, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(12.dp)) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = text)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("الأقسام الرئيسية", fontWeight = FontWeight.Bold, color = text)
                        val modules = listOf(
                            Module("العملاء", 0, "0", Icons.Default.People),
                            Module("الموردون", 0, "0", Icons.Default.LocalShipping),
                            Module("المخزون", 0, "0", Icons.Default.Inventory),
                            Module("الإنتاج", 0, "0", Icons.Default.Factory),
                            Module("المبيعات", 0, "0", Icons.Default.PointOfSale),
                            Module("المشتريات", 0, "0", Icons.Default.ShoppingCart),
                            Module("المصاريف", 0, "0", Icons.Default.ReceiptLong),
                            Module("الموظفون", 0, "0", Icons.Default.Badge),
                            Module("الأصول", 0, "0", Icons.Default.Business),
                            Module("الصناديق والبنوك", 0, "0", Icons.Default.AccountBalance)
                        )
                        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(modules) { m ->
                                Card(Modifier.fillMaxWidth().height(92.dp).clickable { active = m.title }, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(14.dp)) {
                                    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(m.icon, null, tint = blue)
                                            Spacer(Modifier.width(7.dp))
                                            Text(m.title, color = text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("السجلات: ${m.count}", color = text, fontSize = 11.sp)
                                            Text(m.balance, color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("قسم $active", color = text, fontWeight = FontWeight.Bold)
                                Text("سيتم ربط هذا القسم بقاعدة البيانات في مراحل التطوير التالية.", color = text)
                            }
                        }
                    }
                }
            }
        }
        if (showEntry) {
            AlertDialog(
                onDismissRequest = { showEntry = false },
                title = { Text(entryType) },
                text = {
                    Column {
                        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("البيان / الطرف") })
                        OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("المبلغ (أرقام إنجليزية)") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val value = amount.toDoubleOrNull() ?: 0.0
                        if (value > 0) scope.launch {
                            db.entryDao().insert(FinancialEntry(type = entryType, description = description, amount = value, createdAt = System.currentTimeMillis()))
                            records++
                        }
                        amount = ""; description = ""; showEntry = false
                    }) { Text("حفظ") }
                },
                dismissButton = { TextButton(onClick = { showEntry = false }) { Text("إلغاء") } }
            )
        }
    }
}
