package com.abduhbro.accounting.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Entity(tableName = "financial_entries")
data class FinancialEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val description: String,
    val amount: Double,
    val createdAt: Long
)

@Dao
interface EntryDao {
    @Insert suspend fun insert(entry: FinancialEntry)
    @Query("SELECT * FROM financial_entries ORDER BY createdAt DESC")
    suspend fun all(): List<FinancialEntry>
    @Query("SELECT COUNT(*) FROM financial_entries")
    suspend fun count(): Int
}

@Database(entities = [FinancialEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun entryDao(): EntryDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "abduh_bro.db").build().also { INSTANCE = it }
        }
    }
}
